export const API_ENDPOINTS = {
  GET_ALL_TICKET: '/AppRole/getAllTicket',
};

export const Columns = [
  { key: 'ticketId', label: 'S.No.' },
  { key: 'ticketType', label: 'Ticket Type' },
  { key: 'image', label: 'Image' }
];