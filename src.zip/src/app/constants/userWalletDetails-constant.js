export const API_ENDPOINTS = {
    GET_USER_WALLET_DETAILS: "/AdminManageFund/getUserWalletDetails",
    ADD_CREDIT_DEBIT_FUND: "/AdminManageFund/addCreditAndDebitFund",
};