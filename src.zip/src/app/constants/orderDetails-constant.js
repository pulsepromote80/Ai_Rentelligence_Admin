export const API_ENDPOINTS = {
    GET_ORDER_BY_SERACH_ADMIN:"/Order/getOrdersBySearchAdmin"
};

