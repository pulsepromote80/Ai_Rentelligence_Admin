export const API_ENDPOINTS = {
    GET_ALL_COUNTRY: "/Geography/getAllCountry",
    GET_ALL_STATE: "/Geography/getAllState",
    GET_ALL_CITY: "/Geography/getAllCity" 
};

export const Columns = [
    
];