export const chartData = [
    { month: 'Jan', value: 0.5 },
    { month: 'Feb', value: 1 },
    { month: 'Mar', value: 0.7 },
    { month: 'Apr', value: 1.1 },
    { month: 'May', value: 0.9 },
    { month: 'Jun', value: 1.5 },
    { month: 'Jul', value: 1 },
    { month: 'Aug', value: 0.7 },
    { month: 'Sep', value: 0.8 },
    { month: 'Oct', value: 0.6 },
  ];