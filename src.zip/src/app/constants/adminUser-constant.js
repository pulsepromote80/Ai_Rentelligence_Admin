export const Columns = [
    { key: 'username', label: 'UserName' },
    { key: 'firstName', label: 'First Name' },
    { key: 'middleName', label: 'Middle Name' },
    { key: 'lastName', label: 'Last Name' },
    { key: 'email', label: 'Email' },
    { key: 'phoneNumber', label: 'Phone Number' },
    { key: 'createdDate', label: 'Created Date' },
    { key: 'activeStatus', label: 'Status' }, 
    { key: 'password', label: 'Password' }, 
  ];