'use client'
//import AdminLogin from './login/page';
import Home from './Home/page'

export default function HomePage() {
    return(
      <div className='flex items-center justify-center'>
      <Home/>
      </div>
    ) 
}
