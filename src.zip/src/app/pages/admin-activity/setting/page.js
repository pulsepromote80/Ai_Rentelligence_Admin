import React from 'react';

const Setting = () => {
  return (
    <div className="flex items-center justify-center h-full">
      <h1 className="text-3xl font-semibold text-gray-700">Setting Page is Coming Soon 🚧</h1>
    </div>
  );
};

export default Setting;