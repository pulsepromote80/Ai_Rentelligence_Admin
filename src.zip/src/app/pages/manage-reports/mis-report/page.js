import React from 'react';

const MisReport = () => {
  return (
    <div className="flex items-center justify-center h-full mt-5 mb-6">
      <h1 className="text-3xl font-semibold text-gray-700">MisReport Page is Coming Soon 🚧</h1>
    </div>
  );
};

export default MisReport;